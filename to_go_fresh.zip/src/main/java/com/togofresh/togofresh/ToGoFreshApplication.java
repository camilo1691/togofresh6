package com.togofresh.togofresh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ToGoFreshApplication {

	public static void main(String[] args) {
		SpringApplication.run(ToGoFreshApplication.class, args);
	}

}
